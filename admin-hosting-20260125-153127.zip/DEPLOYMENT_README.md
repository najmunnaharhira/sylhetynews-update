﻿# Sylhetly News - Admin Panel Hosting Package

## ðŸ“¦ Package Contents

This package contains the Next.js admin panel for Sylhetly News.

## ðŸš€ Quick Setup

### 1. Install Dependencies
\\\ash
npm install
\\\

### 2. Configure Environment
\\\ash
cp .env.example .env.local
# Edit .env.local with your configuration:
# - Firebase configuration
# - NEXT_PUBLIC_ADMIN_EMAILS: Comma-separated admin emails
\\\

### 3. Build for Production
\\\ash
npm run build
\\\

### 4. Start Server
\\\ash
npm start
\\\

## ðŸ“ Required Environment Variables (.env.local)

\\\env
NEXT_PUBLIC_FIREBASE_API_KEY=your-firebase-api-key
NEXT_PUBLIC_FIREBASE_AUTH_DOMAIN=your-firebase-auth-domain
NEXT_PUBLIC_FIREBASE_PROJECT_ID=your-firebase-project-id
NEXT_PUBLIC_FIREBASE_STORAGE_BUCKET=your-firebase-storage-bucket
NEXT_PUBLIC_FIREBASE_MESSAGING_SENDER_ID=your-firebase-messaging-sender-id
NEXT_PUBLIC_FIREBASE_APP_ID=your-firebase-app-id
NEXT_PUBLIC_ADMIN_EMAILS=admin@example.com,admin2@example.com
\\\

## ðŸŒ Hosting Options

- **Vercel**: Connect GitHub repo (recommended for Next.js)
- **Netlify**: Connect GitHub repo
- **Railway**: Connect GitHub repo
- **Traditional Hosting**: Build and deploy \.next/\ or \out/\ directory

## ðŸ“ Important Files

- \.next/\: Production build output (Next.js)
- \out/\: Static export output (if using static export)
- \public/\: Static assets
- \src/\: Source code
- \.env.example\: Environment variable template

## ðŸ”’ Security Notes

1. Never commit .env.local files
2. Use HTTPS in production
3. Configure admin emails properly
4. Set proper Firebase security rules
5. Use environment variables for all secrets

## ðŸ› ï¸ Static Export (Optional)

If you want to export as static site:
\\\ash
# In next.config.ts, add:
output: 'export'

# Then build:
npm run build
# Deploy the \out/\ directory
\\\

Generated: 2026-01-25 15:31:36
