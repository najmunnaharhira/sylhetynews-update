﻿# Sylhetly News - Backend Hosting Package

## ðŸ“¦ Package Contents

This package contains the Express.js backend API server for Sylhetly News.

## ðŸš€ Quick Setup

### 1. Install Dependencies
\\\ash
npm install
\\\

### 2. Configure Environment
\\\ash
cp .env.example .env
# Edit .env with your configuration:
# - PORT: Server port (default: 5000)
# - MONGODB_URI: MongoDB connection string
# - FRONTEND_URL: Frontend URL
# - ADMIN_EMAIL: Admin email
# - ADMIN_PASSWORD: Admin password
# - Firebase configuration
\\\

### 3. Create Uploads Directory
\\\ash
mkdir uploads
chmod 755 uploads  # Linux/Mac
# Or set proper permissions on Windows
\\\

### 4. Start Server
\\\ash
# Development
npm run dev

# Production
npm start
\\\

## ðŸ“ Required Environment Variables (.env)

\\\env
PORT=5000
NODE_ENV=production
FRONTEND_URL=https://your-frontend-domain.com
MONGODB_URI=mongodb+srv://username:password@cluster.mongodb.net/dbname
ADMIN_EMAIL=admin@example.com
ADMIN_PASSWORD=YourSecurePassword123!

# Firebase Configuration
FIREBASE_API_KEY=your-firebase-api-key
FIREBASE_AUTH_DOMAIN=your-firebase-auth-domain
FIREBASE_PROJECT_ID=your-firebase-project-id
FIREBASE_STORAGE_BUCKET=your-firebase-storage-bucket
FIREBASE_MESSAGING_SENDER_ID=your-firebase-messaging-sender-id
FIREBASE_APP_ID=your-firebase-app-id
\\\

## ðŸŒ Hosting Options

- **Heroku**: Connect GitHub repo or use Heroku CLI
- **Railway**: Connect GitHub repo
- **DigitalOcean App Platform**: Connect GitHub repo
- **AWS EC2**: Deploy manually
- **VPS**: Use PM2 for process management

## ðŸ“ Important Files

- \src/server.js\: Main server file
- \src/routes/\: API routes
- \src/controllers/\: Request handlers
- \src/models/\: Database models
- \uploads/\: File upload directory (create and set permissions)

## ðŸ”’ Security Notes

1. Never commit .env files
2. Use strong admin passwords
3. Enable HTTPS
4. Configure CORS properly
5. Set proper file permissions for uploads directory
6. Use environment variables for all secrets

## ðŸ› ï¸ Process Management (Production)

### Using PM2
\\\ash
npm install -g pm2
pm2 start src/server.js --name sylhetlynews-backend
pm2 save
pm2 startup
\\\

Generated: 2026-01-25 15:31:34
